### R code from vignette source 'iSubpathwayMiner.Rnw'

###################################################
### code chunk number 1: iSubpathwayMiner.Rnw:46-47
###################################################
library(iSubpathwayMiner)


###################################################
### code chunk number 2: iSubpathwayMiner.Rnw:62-67
###################################################
#get path of the KGML files
path<-paste(system.file(package="iSubpathwayMiner"),
"/localdata/kgml/metabolic/ec/",sep="")
#convert pathways to a list in R
p<-getPathway(path,c("ec00010.xml","ec00020.xml"))


###################################################
### code chunk number 3: iSubpathwayMiner.Rnw:80-87
###################################################
#get path of the KGML files
path<-paste(system.file(package="iSubpathwayMiner"),
"/localdata/kgml/metabolic/ec/",sep="")
#convert pathways to a list in R
p<-getPathway(path,c("ec00010.xml"))
#convert metabolic pathways to graphs
gm<-getMetabolicGraph(p)


###################################################
### code chunk number 4: getMetabolicGraph1
###################################################
#name of graph gm[[1]]
gm[[1]]$title
#visualize
plotGraph(gm[[1]])


###################################################
### code chunk number 5: iSubpathwayMiner.Rnw:108-109
###################################################
summary(gm[[1]])


###################################################
### code chunk number 6: iSubpathwayMiner.Rnw:114-115
###################################################
str(gm[["00010"]],v=TRUE,e=TRUE,g=TRUE)


###################################################
### code chunk number 7: iSubpathwayMiner.Rnw:118-121
###################################################
#display a subgraph with 5 nodes.
sgm<-induced.subgraph(gm[[1]],V(gm[[1]])[1:5])
str(sgm,g=TRUE,v=TRUE,e=TRUE)


###################################################
### code chunk number 8: iSubpathwayMiner.Rnw:129-131
###################################################
gm[[1]]$title
gm[[1]]$number


###################################################
### code chunk number 9: iSubpathwayMiner.Rnw:134-135
###################################################
V(gm[[1]])[2]$names


###################################################
### code chunk number 10: iSubpathwayMiner.Rnw:138-139
###################################################
get.vertex.attribute(gm[[1]],"names",2)


###################################################
### code chunk number 11: iSubpathwayMiner.Rnw:143-144
###################################################
V(gm[[1]])[2]$type


###################################################
### code chunk number 12: iSubpathwayMiner.Rnw:151-160
###################################################
#get indexes of nodes
index1<-V(gm[[1]])[V(gm[[1]])$names=="ec:4.1.2.13"]
index2<-V(gm[[1]])[V(gm[[1]])$names=="ec:1.2.1.59"]
#get shortest path
shortest.path<-get.shortest.paths(gm[[1]],index1,index2)
#display shortest path
shortest.path
#convert indexes to names
V(gm[[1]])[shortest.path[[1]]]$names


###################################################
### code chunk number 13: iSubpathwayMiner.Rnw:163-165
###################################################
index1<-V(gm[[1]])[V(gm[[1]])$names=="ec:4.1.2.13"]
betweenness(gm[[1]],index1)


###################################################
### code chunk number 14: iSubpathwayMiner.Rnw:170-176
###################################################
#node index value
as.integer(index1)
#direct display is not real node index value.
index1
#it is equal to the value of the "id" attribute.
index1$id


###################################################
### code chunk number 15: getNonMetabolicGraph1
###################################################
#get path
pathn<-paste(system.file(package="iSubpathwayMiner"),
"/localdata/kgml/non-metabolic/ko/",sep="")
pn<-getPathway(pathn,c("ko04010.xml","ko04020.xml"))
#Convert pathways to graphs
gn1<-getNonMetabolicGraph(pn)
#name of the first pathway
gn1[[1]]$title
#visualize
plotGraph(gn1[[1]])


###################################################
### code chunk number 16: getNonMetabolicGraph2
###################################################
#Convert pathways to graphs with ambiguous edges as deleted
gn2<-getNonMetabolicGraph(pn,ambiguousEdgeDirection="delete")


###################################################
### code chunk number 17: iSubpathwayMiner.Rnw:224-242
###################################################
##get metabolic pathway graphs
#get path of KGML files
path<-paste(system.file(package="iSubpathwayMiner"),
"/localdata/kgml/metabolic/ec/",sep="")
#convert metabolic pathways to graphs
gm<-getMetabolicGraph(getPathway(path,c("ec00010.xml")))
#show title of pathway graphs
sapply(gm,function(x) x$title)

##get non-metabolic pathway graphs
#get path
path1<-paste(system.file(package="iSubpathwayMiner"),
"/localdata/kgml/non-metabolic/ko/",sep="")
#convert non-metabolic pathways to graphs
gn<-getNonMetabolicGraph(getPathway(path1,c("ko04010.xml")),
ambiguousEdgeDirection="bi-directed")
#show title of pathway graphs
sapply(gn,function(x) x$title)


###################################################
### code chunk number 18: getUGraph
###################################################
#get undirected pathway graphs
g1<-getUGraph(gm,simpleGraph=TRUE)


###################################################
### code chunk number 19: iSubpathwayMiner.Rnw:257-258
###################################################
getOrgAndIdType()


###################################################
### code chunk number 20: mapNode
###################################################
#see the names attribute of nodes. 
V(gm[[1]])[1:10]$names
#get the organism-specific and idType-specific graph
g1<-mapNode(gm)
#see the names attribute of nodes in the new graph. 
#some node names are revised as NCBI-gene IDs 
V(g1[[1]])[1:10]$names


###################################################
### code chunk number 21: filterNode
###################################################
#We display them before nodes are filtered
V(gn[[1]])$type
#delete nodes with type="map"
g1<-filterNode(gn,nodeType=c("map"))
#The "map" nodes are deleted in the new graph. 
V(g1[[1]])$type


###################################################
### code chunk number 22: simplifyGraphGene
###################################################
#get graphs with enzymes as nodes and compounds as edges
g1<-simplifyGraph(gm,nodeType="geneProduct")
#see the names attribute of three edges
E(g1[[1]])[1:3]$names


###################################################
### code chunk number 23: simplifyGraphCompound
###################################################
#get graphs with compounds as nodes and enzymes as edges
g2<-simplifyGraph(gm,nodeType="compound")
#see the names attribute of three edges
E(g2[[1]])[1:3]$names


###################################################
### code chunk number 24: iSubpathwayMiner.Rnw:316-323
###################################################
#We firstly display node number before nodes are expanded
vcount(gn[[1]])
##expand nodes in Graphs
g1<-expandNode(gn)
#We can see change of node number in the new graph:
#node number after nodes are expanded
vcount(g1[[1]])


###################################################
### code chunk number 25: iSubpathwayMiner.Rnw:329-331
###################################################
#only expand nodes with type="enzyme" or "ortholog" in graphs
g2<-expandNode(gn,nodeType=c("ortholog","enzyme"))


###################################################
### code chunk number 26: iSubpathwayMiner.Rnw:339-340
###################################################
all(sapply(gm,is.simple))


###################################################
### code chunk number 27: mergeNode
###################################################
#get node number before merge
vcount(gm[[1]])
#merge nodes
g1<-mergeNode(gm,simple=FALSE)
#get node number after merge
vcount(g1[[1]])


###################################################
### code chunk number 28: combination1-1
###################################################
#get graphs with enzymes and compounds as nodes
g1<-filterNode(gm,nodeType=c("map"))
#visualize
plotGraph(g1[[1]])


###################################################
### code chunk number 29: iSubpathwayMiner.Rnw:539-548
###################################################
#get path of KGML files
path<-paste(system.file(package="iSubpathwayMiner"),
"/localdata/kgml/metabolic/ec/",sep="")
#convert metabolic pathways to graphs with "map" node deleted
gmf<-filterNode(getMetabolicGraph(getPathway(path,c("ec00010.xml"))))
#show title of pathway graphs
sapply(gmf,function(x) x$title)
#convert metablic pathways to graphs with enzymes as nodes and compounds as edges
gmfs<-simplifyGraph(gmf,nodeType="geneProduct")


###################################################
### code chunk number 30: baseGraph2
###################################################
#visualize annotated graph
plotGraph(gmfs[[1]])


###################################################
### code chunk number 31: iSubpathwayMiner.Rnw:567-569
###################################################
#get degree of nodes
igraph::degree(gmfs[[1]],1)


###################################################
### code chunk number 32: iSubpathwayMiner.Rnw:572-574
###################################################
#see name of the first node
V(gmfs[[1]])[1]$names


###################################################
### code chunk number 33: iSubpathwayMiner.Rnw:579-583
###################################################
#get indexes of nodes
index1<-V(gmfs[[1]])[V(gmfs[[1]])$names=="ec:4.1.2.13"]
#get degree of node
igraph::degree(gmfs[[1]],index1)


###################################################
### code chunk number 34: iSubpathwayMiner.Rnw:588-590
###################################################
#Calculate betweenness of enzyme "ec:4.1.2.13".
betweenness(gmfs[[1]],index1)


###################################################
### code chunk number 35: iSubpathwayMiner.Rnw:595-597
###################################################
#Calculate the clustering coefficient of enzyme "ec:4.1.2.13".
igraph::transitivity(gmfs[[1]],type="local",vids=index1)


###################################################
### code chunk number 36: iSubpathwayMiner.Rnw:604-606
###################################################
#get the shortest path
shortest.path<-get.shortest.paths(gmf[[1]],1,2,mode="out")


###################################################
### code chunk number 37: iSubpathwayMiner.Rnw:609-613
###################################################
#see name of the first and second nodes
V(gmf[[1]])[1:2]$names
#see name of nodes in the shortest path
V(gmf[[1]])[shortest.path[[1]]]$names


###################################################
### code chunk number 38: iSubpathwayMiner.Rnw:619-628
###################################################
#get indexes of nodes
index1<-V(gmf[[1]])[V(gmf[[1]])$names=="ec:4.1.2.13"]
index2<-V(gmf[[1]])[V(gmf[[1]])$names=="ec:1.2.1.3"]
#get shortest path
shortest.path<-get.shortest.paths(gmf[[1]],index1,index2)
#display shortest path
shortest.path
#convert indexs to names
V(gmf[[1]])[shortest.path[[1]]]$names


###################################################
### code chunk number 39: iSubpathwayMiner.Rnw:633-635
###################################################
#degree distribution.
degree.distribution<-degree.distribution(gmfs[[1]])


###################################################
### code chunk number 40: iSubpathwayMiner.Rnw:639-641
###################################################
#get diameter
diameter(gmfs[[1]])


###################################################
### code chunk number 41: iSubpathwayMiner.Rnw:645-647
###################################################
#Calculate the clustering coefficient.
igraph::transitivity(gmfs[[1]])


###################################################
### code chunk number 42: iSubpathwayMiner.Rnw:651-653
###################################################
#Calculate the density.
graph.density(gmfs[[1]])


###################################################
### code chunk number 43: iSubpathwayMiner.Rnw:670-679
###################################################
#get pathway graphs with enzymes as nodes.
graphList<-getMetabolicECECGraph()
#get a set of genes
geneList<-getExample(geneNumber=1000,compoundNumber=0)
#topology-based pathway analysis
ann<-identifyTopo(geneList,graphList,type="gene",propertyName="degree")
result<-printTopo(ann)
#print a part of the result
result[1:5,]


###################################################
### code chunk number 44: TopologyPlotAnnGraphGene
###################################################
#visualize
plotAnnGraph("path:00562",graphList,ann)


###################################################
### code chunk number 45: iSubpathwayMiner.Rnw:729-732
###################################################
##Convert all metabolic pathways to graphs.
metabolicEC<-get("metabolicEC",envir=k2ri)
graphList<-getMetabolicGraph(metabolicEC)


###################################################
### code chunk number 46: iSubpathwayMiner.Rnw:735-744
###################################################
##get a set of genes
geneList<-getExample(geneNumber=1000)
#annotate gene sets to pathway graphs 
#and identify significant pathway graphs
ann<-identifyGraph(geneList,graphList)
#convert ann to data.frame
result<-printGraph(ann)
#print a part of the results to screen
result[1:10,]


###################################################
### code chunk number 47: iSubpathwayMiner.Rnw:763-765
###################################################
#list of the result
ann[1]


###################################################
### code chunk number 48: iSubpathwayMiner.Rnw:770-771
###################################################
result[result[,1] %in% "path:00010",]


###################################################
### code chunk number 49: entirePlotAnnGraphGene
###################################################
#visualize
plotAnnGraph("path:00010",graphList,ann)


###################################################
### code chunk number 50: iSubpathwayMiner.Rnw:794-801
###################################################
#get a set of compounds
compoundList<-getExample(geneNumber=0,compoundNumber=100)
#annotate compound sets and identify significant pathways
ann<-identifyGraph(compoundList,graphList,type="compound")
result<-printGraph(ann)
#display a part of the result
result[1:5,c(1,3:6)]


###################################################
### code chunk number 51: iSubpathwayMiner.Rnw:807-815
###################################################
#get a set of compounds and genes
moleculeList<-getExample(geneNumber=1000,compoundNumber=100)
#annotate gene and compound sets to metabolic graphs 
#and identify significant graphs
ann<-identifyGraph(moleculeList,graphList,type="gene_compound")
result<-printGraph(ann)
#display a part of results
result[1:5,c(1,3:6)]


###################################################
### code chunk number 52: iSubpathwayMiner.Rnw:822-836
###################################################
##Convert all metabolic pathways to graphs.
metabolicKO<-get("metabolicKO",envir=k2ri)
gm<-getMetabolicGraph(metabolicKO)
##Convert all non-metabolic pathways to graphs, 
nonMetabolicKO<-get("nonMetabolicKO",envir=k2ri)
gn<-getNonMetabolicGraph(nonMetabolicKO)
graphList<-c(gm,gn)
##get a set of genes
geneList<-getExample(geneNumber=1000,compoundNumber=0)
#annotate gene sets and identify significant pathways
ann<-identifyGraph(geneList,graphList,type="gene")
result<-printGraph(ann)
#display part of results
result[1:5,c(1,3,4,5,6)]


###################################################
### code chunk number 53: iSubpathwayMiner.Rnw:841-851
###################################################
##Convert all metabolic pathways to graphs.
metabolicKO<-get("metabolicKO",envir=k2ri)
graphList<-getMetabolicGraph(metabolicKO)
##get a set of genes
geneList<-getExample(geneNumber=1000,compoundNumber=0)
#annotate gene sets and identify significant pathways
ann<-identifyGraph(geneList,graphList)
result<-printGraph(ann)
#display part of results
result[1:10,c(1,3,4,5,6)]


###################################################
### code chunk number 54: iSubpathwayMiner.Rnw:860-873
###################################################
##identify metabolic subpathways based on gene sets
#get the enzyme-enzyme pathway graphs
graphList<-getMetabolicECECUGraph()
#get all 4-clique subgraphs
subGraphList<-getKcSubiGraph(k=4,graphList)
#get a set of genes
geneList<-getExample(geneNumber=1000,compoundNumber=0)
#annotate gene sets to subpathways 
#and identify significant graphs
ann<-identifyGraph(geneList,subGraphList,type="gene")
result<-printGraph(ann)
#display a part of results
result[1:15,c(1,3,4,5,6)]


###################################################
### code chunk number 55: iSubpathwayMiner.Rnw:882-890
###################################################
#get a set of interesting genes and metabolites
moleculeList<-getExample(geneNumber=1000,compoundNumber=100)
#identify subpathways
reGM<-SubpathwayGM(moleculeList,n=5,s=5)
#convert ann to data.frame
result<-printGraph(reGM$ann)
#print the results
result[1:10,]


###################################################
### code chunk number 56: SubpathwayiGCompound
###################################################
plotAnnGraph("path:00010_1",reGM$subGraphList,reGM$ann,displayInR=TRUE,gotoKEGG=FALSE)


###################################################
### code chunk number 57: entirePlotAnnGraphGeneV
###################################################
#visualize
plotAnnGraph("path:00010_1",reGM$subGraphList,reGM$ann,displayInR=TRUE,gotoKEGG=TRUE)


###################################################
### code chunk number 58: iSubpathwayMiner.Rnw:921-933
###################################################
#read differential genes and metabolites in colorectal cancer from files
path1<-paste(system.file(package="iSubpathwayMiner"),"/localdata/crc_diff_gene.txt",sep="")
geneList<-as.character(read.table(path1,sep="\t")[[1]])
path2<-paste(system.file(package="iSubpathwayMiner"),"/localdata/crc_diff_metabolite.txt",sep="")
metaboliteList<-as.character(read.table(path2,sep="\t")[[1]])
moleculeList<-c(geneList,metaboliteList)
#identify metabolic subpathways 
reGM<-SubpathwayGM(moleculeList,n=5,s=5)
#convert ann to data.frame
result<-printGraph(reGM$ann)
#print the significant subpathways to screen
result[which(result[,"pvalue"]<0.01),]


###################################################
### code chunk number 59: iSubpathwayMiner.Rnw:937-939
###################################################
result1<-printGraph(reGM$ann,detail=TRUE)
write.table(result1,file="result1.txt",row.names=FALSE,sep="\t")


###################################################
### code chunk number 60: iSubpathwayMiner.Rnw:953-956
###################################################
path<-paste(system.file(package="iSubpathwayMiner"),
"/localdata/kgml/metabolic/ec/",sep="")
gm<-getMetabolicGraph(getPathway(path,c("ec00010.xml")))


###################################################
### code chunk number 61: keggStyle1
###################################################
#visualize
plotGraph(gm[[1]])


###################################################
### code chunk number 62: metabolicSymbol
###################################################
plotGraph(gm[[1]],vertex.label=getNodeLabel(gm[[1]],
type="currentId",displayNumber=1))


###################################################
### code chunk number 63: colorFrameGraphSet
###################################################
#add red frame to the enzyme "ec:4.1.2.13" 
vertex.frame.color<-ifelse(V(gm[[1]])$names=="ec:4.1.2.13","red","dimgray")
vertex.frame.color
#display new graph
plotGraph(gm[[1]],vertex.frame.color=vertex.frame.color)


###################################################
### code chunk number 64: newGraphSet
###################################################
#add green label to the comound "cpd:C00111" 
vertex.label.color<-ifelse(V(gm[[1]])$names=="cpd:C00111","green","dimgray")
#change node color
vertex.color<-sapply(V(gm[[1]])$type,function(x) if(x=="enzyme"){"pink"}
else if(x=="compound"){"yellow"} else{"white"})
#change node size
size<-ifelse(V(gm[[1]])$graphics_name=="Starch and sucrose metabolism",20,8)
#change a compound label
#font size
vertex.label.cex<-ifelse(V(gm[[1]])$names=="cpd:C00036",1.0,0.6)
#italic
vertex.label.font<-ifelse(V(gm[[1]])$names=="cpd:C00036",3,1)
#change y coordinate of an enzyme
layout<-getLayout(gm[[1]])
index<-V(gm[[1]])[V(gm[[1]])$names=="ec:4.1.1.32"]
layout[index+1,2]<-layout[index+1,2]+50
#display the new graph 
plotGraph(gm[[1]],vertex.frame.color=vertex.frame.color,
vertex.label.color=vertex.label.color,vertex.color=vertex.color,
vertex.size=size,vertex.size2=size,vertex.label.cex=vertex.label.cex,
vertex.label.font=vertex.label.font,layout=layout)


###################################################
### code chunk number 65: layoutrandom
###################################################
plotGraph(gm[[1]],layout=layout.random)


###################################################
### code chunk number 66: layoutcircle
###################################################
plotGraph(gm[[1]],layout=layout.circle)


###################################################
### code chunk number 67: iSubpathwayMiner.Rnw:1062-1070
###################################################
##Convert all metabolic pathways to graphs.
metabolicEC<-get("metabolicEC",envir=k2ri)
graphList<-getMetabolicGraph(metabolicEC)
##get a set of genes
geneList<-getExample(geneNumber=1000)
#annotate gene sets to pathway graphs 
#and identify significant pathway graphs
ann<-identifyGraph(geneList,graphList)


###################################################
### code chunk number 68: entirePlotAnnGraphGeneV
###################################################
#visualize
plotAnnGraph("path:00010",graphList,ann)


###################################################
### code chunk number 69: entirePlotAnnGraphGeneV
###################################################
#visualize
plotAnnGraph("path:00010",graphList,ann,gotoKEGG=TRUE)


###################################################
### code chunk number 70: iSubpathwayMiner.Rnw:1098-1099
###################################################
write.graph(gm[[1]], "ec00010.txt", "gml")


###################################################
### code chunk number 71: iSubpathwayMiner.Rnw:1103-1105
###################################################
##data in environment variable k2ri
ls(k2ri)


###################################################
### code chunk number 72: iSubpathwayMiner.Rnw:1109-1111
###################################################
#get all metabolic pathway data
metabolicEC<-get("metabolicEC",envir=k2ri)


###################################################
### code chunk number 73: iSubpathwayMiner.Rnw:1117-1118
###################################################
getOrgAndIdType()


###################################################
### code chunk number 74: iSubpathwayMiner.Rnw:1125-1127 (eval = FALSE)
###################################################
## path<-paste(system.file(package="iSubpathwayMiner"),"/localdata",sep="")
## updateOrgAndIdType("sce","sgd-sce",path)


###################################################
### code chunk number 75: iSubpathwayMiner.Rnw:1140-1141 (eval = FALSE)
###################################################
## saveK2ri("sce_sgd-sce.rda")


###################################################
### code chunk number 76: iSubpathwayMiner.Rnw:1146-1147 (eval = FALSE)
###################################################
## loadK2ri("sce_sgd-sce.rda")


###################################################
### code chunk number 77: sessionInfo
###################################################
sessionInfo()


